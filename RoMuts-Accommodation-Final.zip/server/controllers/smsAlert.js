const twilio = require("twilio");

const client = new twilio('TWILIO_SID', 'TWILIO_AUTH_TOKEN');

exports.sendSMS = async (req, res) => {
  const { message, to } = req.body;

  client.messages
    .create({
      body: message,
      from: '+YOUR_TWILIO_PHONE_NUMBER',
      to: to
    })
    .then(msg => res.json({ status: 'sent', sid: msg.sid }))
    .catch(err => res.status(500).json({ error: err.message }));
};