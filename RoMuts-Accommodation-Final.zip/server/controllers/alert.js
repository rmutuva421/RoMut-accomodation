const twilio = require("twilio");

const client = new twilio('TWILIO_SID', 'TWILIO_AUTH_TOKEN');

exports.sendAlert = async (req, res) => {
  const { message, to } = req.body;

  client.messages
    .create({
      body: message,
      from: 'whatsapp:+14155238886',
      to: `whatsapp:${to}`
    })
    .then(msg => res.json({ status: 'sent', sid: msg.sid }))
    .catch(err => res.status(500).json({ error: err.message }));
};